const nama = "danish";
let umur = 10;

 function generateBiodata() {
    if (umur > 30 && umur <18) { //false
         //ini adalah kondisi pertama
         console.log(`anda dewasa`)
    } else{
       //ini adalah jika kondisi tidak berfungsi
       console.log(`anda anak-anak`)
    }
 }

 console.log(nama);
 console.log(umur);

 generateBiodata();       

